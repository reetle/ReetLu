 function printDiv() { 
            var divContents = document.getElementById("tabel").innerHTML; 
            var a = window.open(); 
            
        
          a.document.write('<html>'); 
           a.document.write('<body>'); 
          a.document.write(divContents); 
          a.document.write('<td/></body></html>'); 
           a.document.close(); 
            a.print(); 
           
        }