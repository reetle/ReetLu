
<!DOCTYPE html>
<html>
<head>
<title>Raamatukogu fond</title>
<meta charset="UTF-8" />
<meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no, width=device-width" /> <!-- avab lehe seadme suurusega-->
<link rel="stylesheet" href="style.css" type="text/css"/>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

</head>
<body> 
      <?php
include_once("header.php");
?>   
<div class= "menu">
		<ul style="list-style-type:none">
			<li> <a href="book_data.php"> Raamatud</a> </li>  
			<li> <a href="textbook_data.php"> Õpikud </a></li>
			<li> <a href="periodicals_data.php">Perioodika</a></li>
			<li> <a href="audio_data.php">Audio-Video</a></li>	
			<li> <a href="workbook_data.php">Töövihikud</a></li>
			<li> <a href="meth_library_data.php">Metoodiline kirjandus</a></li>	<br>           
			<li><a href="menu.php">Esilehele</a> </li>
			
		</ul>
</div>
</body>
</html>