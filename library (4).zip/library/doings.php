<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="style.css" type="text/css"/>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
<title>Toimingud</title>
</head>
<body> 
    <?php
include_once("header.php");
?>   

  



	<div class= "menu">
		<ul style="list-style-type:none">
			<li> <a href="borrow.php">Laenutamine</a> </li>  
		<!--	<li> <a href="#">Tellimine </a></li>-->
			<li> <a href="write_off.php">Mahakandmine</a></li>
		<!--	<li> <a href="#">Inventuur</a></li>	-->
		<!--	<li> <a href="#">Ekspordi internetti</a></li>	--> <br> 
			<li><a href="menu.php">Esilehele</a> </li>
			
		</ul>
	</div> 
	



</body>
</html>